import React from 'react';
import './App.css';
import DrawPage from './page/DrawPage';

function App(): JSX.Element {
  return (
    <>
      <DrawPage />
    </>
  );
}

export default App;


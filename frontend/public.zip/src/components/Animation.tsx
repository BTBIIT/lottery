import React, { useEffect, useState } from 'react';
import Ball from './assets/ball_1.svg'; // SVG 파일 경로

function Animation() {
  const [balls, setBalls] = useState([
    { id: 1, cx: 50, cy: 50, r: 20, fill: 'yellow' },
    { id: 2, cx: 100, cy: 100, r: 20, fill: 'green' },
    { id: 3, cx: 150, cy: 150, r: 20, fill: 'blue' },
    { id: 4, cx: 200, cy: 50, r: 20, fill: 'red' },
    { id: 5, cx: 250, cy: 100, r: 20, fill: 'black' },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setBalls(prevBalls =>
        prevBalls.map(ball => ({
          ...ball,
          cx: Math.random() * 300,
          cy: Math.random() * 300,
        }))
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <svg width="300" height="300" style={{ backgroundColor: 'lightgray' }}>
      {balls.map(ball => (
        <image 
          key={ball.id} 
          href={Ball} 
          x={ball.cx - 10} 
          y={ball.cy - 10} 
          width="20" 
          height="20" 
        />
      ))}
    </svg>
  );
}

export default Animation;

import React, { useState } from "react";

interface ButtonProps {
  selected: "normal" | "special";
}

function Button({ selected }: ButtonProps) {
  const [result, setResult] = useState<string | null>(null);

  const handleClick = async (drawCount: number) => {
    try {
      let endpoint = "";
      if (selected === "normal") {
        endpoint =
          drawCount === 1
            ? "http://localhost:5000/api/single-draw"
            : "http://localhost:5000/api/multiple-draws";
      } else if (selected === "special") {
        endpoint =
          drawCount === 1
            ? "http://localhost:5000/api/draw-limited"
            : "http://localhost:5000/api/draw-limited-multiple";
      }

      console.log("Requesting API endpoint:", endpoint);

      const response = await fetch(endpoint);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setResult(JSON.stringify(data, null, 2));
    } catch (error) {
      console.error("API 호출 중 오류 발생:", error);
      setResult("오류 발생: 데이터를 가져올 수 없습니다.");
    }
  };

  return (
    <div className="w-[800px] flex flex-col items-center space-y-6 mt-5">
      <div className="w-[600px] flex justify-between">
        <button
          onClick={() => handleClick(1)}
          className="w-[270px] bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 transition text-[20px] font-bold shadow-lg"
        >
          1회 추첨
        </button>
        <button
          onClick={() => handleClick(5)}
          className="w-[270px] bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 transition text-[20px] font-bold shadow-lg"
        >
          5회 추첨
        </button>
      </div>
      <pre className="mt-6 bg-gray-200 p-4 rounded w-full max-w-[800px] overflow-auto">
        {result || "결과가 여기에 표시됩니다."}
      </pre>
    </div>
  );
}

export default Button;

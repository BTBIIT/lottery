module.exports = {
  content: [
  	"./src/**/*.{js,jsx,ts,tsx}",  
  ],
   corePlugins: {
    preflight: true, // Preflight를 활성화
  },
  theme: {
    extend: {},
  },
  plugins: [],
}